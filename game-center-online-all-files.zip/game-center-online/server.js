'use strict';
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, methods: ['GET','POST'] } });
const PORT = process.env.PORT || 3000;
const rooms = new Map();
const STAGES = [{n:3,k:3},{n:4,k:4},{n:5,k:4},{n:6,k:4},{n:7,k:5},{n:8,k:5}];
const DIRS = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];

app.use(express.static(__dirname));
app.get('/health', (_req,res) => res.json({ ok:true, rooms:rooms.size }));

function cleanName(v) { return String(v || 'プレイヤー').trim().replace(/[<>\u0000-\u001f]/g,'').slice(0,12) || 'プレイヤー'; }
function codeNew() {
  for (let i=0;i<100;i++) { const c=String(crypto.randomInt(0,1000000)).padStart(6,'0'); if (!rooms.has(c)) return c; }
  throw new Error('部屋を作成できませんでした。少し待って再試行してください。');
}
function publicRoom(r) {
  return { code:r.code, game:r.game, stage:r.stage, started:r.started, players:r.players.map(p=>({name:p.name, connected:!!p.socketId, host:p.host})), state:r.state, result:r.result, message:r.message || '' };
}
function sendRoom(r) { io.to(r.code).emit('roomUpdate', publicRoom(r)); }
function getPlayer(r,socket) { return r.players.find(p=>p.socketId===socket.id); }
function tttState(stage) {
  const s=STAGES[stage]; return { board:Array(s.n*s.n).fill(null), n:s.n, k:s.k, turn:'X', over:false, winner:null, winningLine:[] };
}
function tttResult(b,n,k) {
  const dirs=[[0,1],[1,0],[1,1],[1,-1]];
  for(let i=0;i<b.length;i++) if(b[i]) {
    const r=i/n,c=i%n;
    for(const [dr,dc] of dirs) {
      const cells=[]; for(let j=0;j<k;j++){const rr=r+dr*j,cc=c+dc*j;if(rr<0||rr>=n||cc<0||cc>=n)break;cells.push(rr*n+cc);}
      if(cells.length===k && cells.every(x=>b[x]===b[i])) return {winner:b[i],line:cells};
    }
  }
  return b.every(Boolean)?{winner:'draw',line:[]}:null;
}
function othelloLegal(b,p) {
  const out=[];
  for(let i=0;i<64;i++) if(!b[i]) { const f=othelloFlips(b,i,p); if(f.length)out.push(i); }
  return out;
}
function othelloFlips(b,i,p) {
  if(b[i])return[]; const r0=i>>3,c0=i&7,out=[];
  for(const [dr,dc] of DIRS){let r=r0+dr,c=c0+dc,line=[];while(r>=0&&r<8&&c>=0&&c<8&&b[r*8+c]===-p){line.push(r*8+c);r+=dr;c+=dc;}if(line.length&&r>=0&&r<8&&c>=0&&c<8&&b[r*8+c]===p)out.push(...line);}
  return out;
}
function othelloState(){const b=Array(64).fill(0);b[27]=-1;b[28]=1;b[35]=1;b[36]=-1;return{board:b,turn:1,over:false,winner:null,lastMove:null,passed:false};}
function finishOthello(s){const black=s.board.filter(v=>v===1).length,white=s.board.filter(v=>v===-1).length;s.over=true;s.winner=black===white?'draw':black>white?1:-1;s.counts={black,white};}
function roomForSocket(socket){for(const r of rooms.values())if(r.players.some(p=>p.socketId===socket.id))return r;return null;}
function roomError(socket,msg){socket.emit('roomError',msg);}

io.on('connection', socket => {
  socket.on('createRoom', ({name,game,stage}={}) => {
    if(!['ttt','oth'].includes(game))return roomError(socket,'ゲームを選択してください。');
    const st=game==='ttt'?Math.max(0,Math.min(5,Number(stage)||0)):0;
    const code=codeNew(), token=crypto.randomBytes(18).toString('hex');
    const r={code,game,stage:st,hostToken:token,players:[{token,name:cleanName(name),socketId:socket.id,host:true}],started:false,state:null,result:null,disconnectTimers:new Map(),message:''};
    rooms.set(code,r);socket.join(code);socket.emit('roomCreated',{code,token});sendRoom(r);
  });
  socket.on('joinRoom', ({code,name,token}={}) => {
    code=String(code||'').replace(/\D/g,'').slice(0,6);const r=rooms.get(code);
    if(!r)return roomError(socket,'その部屋番号は見つかりません。');
    let p=token?r.players.find(x=>x.token===token):null;
    if(p){if(p.socketId&&p.socketId!==socket.id){const old=io.sockets.sockets.get(p.socketId);if(old)old.leave(code);}p.socketId=socket.id;p.name=cleanName(name||p.name);const timer=r.disconnectTimers.get(p.token);if(timer)clearTimeout(timer);r.disconnectTimers.delete(p.token);socket.join(code);r.message='再接続しました。';socket.emit('roomJoined',{code,token:p.token,host:p.host});sendRoom(r);if(r.started)socket.emit('gameState',publicRoom(r));return;}
    if(r.players.length>=2)return roomError(socket,'この部屋は満員です。');
    if(r.started)return roomError(socket,'この対戦はすでに始まっています。');
    const newToken=crypto.randomBytes(18).toString('hex');r.players.push({token:newToken,name:cleanName(name),socketId:socket.id,host:false});socket.join(code);socket.emit('roomJoined',{code,token:newToken,host:false});r.message='対戦相手が参加しました。';sendRoom(r);
  });
  socket.on('startGame',()=>{
    const r=roomForSocket(socket);if(!r)return;const p=getPlayer(r,socket);
    if(!p?.host)return roomError(socket,'部屋の作成者だけが開始できます。');
    if(r.players.length!==2||r.players.some(x=>!x.socketId))return roomError(socket,'2人揃ってから開始してください。');
    if(r.started)return;
    r.started=true;r.result=null;r.state=r.game==='ttt'?tttState(r.stage):othelloState();r.message='対戦開始！';sendRoom(r);
  });
  socket.on('tttMove',({index}={})=>{
    const r=roomForSocket(socket);if(!r||!r.started||r.game!=='ttt'||r.state.over||r.players.some(x=>!x.socketId))return;const p=getPlayer(r,socket);if(!p)return;
    const mark=p.host?'X':'O',s=r.state,i=Number(index);
    if(s.turn!==mark||!Number.isInteger(i)||i<0||i>=s.board.length||s.board[i])return;
    s.board[i]=mark;const result=tttResult(s.board,s.n,s.k);if(result){s.over=true;s.winner=result.winner;s.winningLine=result.line;}else s.turn=mark==='X'?'O':'X';sendRoom(r);
  });
  socket.on('othelloMove',({index}={})=>{
    const r=roomForSocket(socket);if(!r||!r.started||r.game!=='oth'||r.state.over||r.players.some(x=>!x.socketId))return;const p=getPlayer(r,socket);if(!p)return;
    const mark=p.host?1:-1,s=r.state,i=Number(index);if(s.turn!==mark||!Number.isInteger(i)||i<0||i>=64)return;
    const f=othelloFlips(s.board,i,mark);if(!f.length)return;s.passed=false;s.board[i]=mark;for(const x of f)s.board[x]=mark;s.lastMove=i;
    s.turn=-mark;
    if(!othelloLegal(s.board,s.turn).length){s.turn=-s.turn;s.passed=true;if(!othelloLegal(s.board,s.turn).length)finishOthello(s);}
    sendRoom(r);
  });
  socket.on('rematch',()=>{const r=roomForSocket(socket);if(!r||!r.started||!r.state?.over)return;const p=getPlayer(r,socket);if(!p?.host)return;r.state=r.game==='ttt'?tttState(r.stage):othelloState();r.result=null;r.message='新しい対戦を開始しました。';sendRoom(r);});
  socket.on('leaveRoom',()=>{const r=roomForSocket(socket);if(!r)return;const p=getPlayer(r,socket);if(!p)return;const other=r.players.find(x=>x!==p);if(other){r.started=false;r.result={winner:other.host?'X':'O',reason:'相手が退出しました。'};r.message=`${p.name}が退出しました。`;if(other.socketId)io.to(other.socketId).emit('opponentLeft',{winner:r.result.winner,message:r.message});}for(const x of r.players){if(x.socketId){const s=io.sockets.sockets.get(x.socketId);if(s)s.leave(r.code);}}rooms.delete(r.code);});
  socket.on('disconnect',()=>{
    const r=roomForSocket(socket);if(!r)return;const p=getPlayer(r,socket);if(!p)return;p.socketId=null;r.message=`${p.name}の再接続を待っています（60秒）。`;sendRoom(r);
    const timer=setTimeout(()=>{const still=rooms.get(r.code);if(!still)return;const lost=still.players.find(x=>x.token===p.token);if(!lost||lost.socketId)return;const other=still.players.find(x=>x!==lost);if(other){const winner=other.host?'X':'O';io.to(still.code).emit('opponentLeft',{winner,message:'60秒以内に再接続できなかったため、対戦を終了しました。'});}rooms.delete(still.code);},60000);
    r.disconnectTimers.set(p.token,timer);
  });
});
server.listen(PORT,()=>console.log(`Game Center running on port ${PORT}`));
