'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const socket = io();
  const sessionKey = 'gcOnlineSession';
  let session = null, room = null, myToken = null, myHost = false;
  let lastRoomCode = null;
  const savedName = localStorage.getItem('gcPlayerName') || '';
  $('online-name').value = savedName;
  $('create-game').addEventListener('change', () => { $('create-stage-wrap').hidden = $('create-game').value !== 'ttt'; });
  $('save-name').onclick = saveName;
  $('create-room').onclick = () => {
    const name = saveName(); if (!name) return;
    setStatus('部屋を作成しています…');
    socket.emit('createRoom', {name, game:$('create-game').value, stage:Number($('create-stage').value)});
  };
  $('join-room').onclick = () => {
    const name = saveName(); if (!name) return;
    const code = $('room-code-input').value.replace(/\D/g,'');
    if (code.length !== 6) return setStatus('部屋番号は6桁で入力してください。');
    setStatus('部屋に接続しています…');
    socket.emit('joinRoom', {code,name});
  };
  $('room-code-input').addEventListener('input', e => { e.target.value=e.target.value.replace(/\D/g,'').slice(0,6); });
  $('start-online').onclick = () => socket.emit('startGame');
  $('leave-wait').onclick = leaveRoom;
  $('leave-match').onclick = leaveRoom;
  $('rematch-online').onclick = () => socket.emit('rematch');

  function saveName() {
    const name = $('online-name').value.trim().replace(/[<>\u0000-\u001f]/g,'').slice(0,12);
    if (!name) { setStatus('プレイヤー名を入力してください。'); $('online-name').focus(); return ''; }
    localStorage.setItem('gcPlayerName',name); $('online-name').value=name; $('name-status').textContent='保存しました'; return name;
  }
  function setStatus(msg) { $('online-status').textContent=msg; }
  function showOnlinePanel(which) {
    $('online-menu').hidden=which!=='menu';$('online-wait').hidden=which!=='wait';$('online-match').hidden=which!=='match';
    showView('online');
  }
  function persistSession() { if(session) localStorage.setItem(sessionKey,JSON.stringify(session)); }
  function clearSession() { session=null;myToken=null;myHost=false;localStorage.removeItem(sessionKey); }
  function enterRoom(code,token,host) {
    session={code,token};myToken=token;myHost=!!host;persistSession();lastRoomCode=code;showOnlinePanel('wait');
  }
  socket.on('connect', () => {
    const raw=localStorage.getItem(sessionKey); if(!raw)return;
    try { const s=JSON.parse(raw); if(s.code&&s.token){session=s;socket.emit('joinRoom',{code:s.code,token:s.token,name:localStorage.getItem('gcPlayerName')||'プレイヤー'});} } catch { clearSession(); }
  });
  socket.on('roomCreated', ({code,token}) => enterRoom(code,token,true));
  socket.on('roomJoined', ({code,token,host}) => enterRoom(code,token,!!host));
  socket.on('roomError', msg => { setStatus(msg); if(session && String(msg).includes('見つかりません')){clearSession();room=null;showOnlinePanel('menu');} });
  socket.on('roomUpdate', data => { room=data; renderRoom(); if(data.started) {showOnlinePanel('match');renderMatch();} else showOnlinePanel('wait'); });
  socket.on('gameState', data => { room=data;showOnlinePanel('match');renderMatch(); });
  socket.on('opponentLeft', data => {
    if(room){room.result=room.result||{winner:data.winner,reason:data.message};room.state=room.state||{};}
    $('match-status').textContent=data.message || '相手が退出しました。';$('rematch-online').hidden=true;document.querySelectorAll('#online-ttt-board button, #online-o-board button').forEach(b=>b.disabled=true);
    if(showView) showView('online'); $('online-menu').hidden=true;$('online-wait').hidden=true;$('online-match').hidden=false;
  });
  socket.on('disconnect', () => { if(room && room.started) $('match-status').textContent='通信が切断されました。再接続を試みています…（最大60秒）'; else if(session) setStatus('通信が切断されました。再接続しています…'); });
  socket.on('connect_error', () => setStatus('サーバーに接続できません。時間をおいて再試行してください。'));

  function renderRoom() {
    if(!room)return;
    $('room-code-display').textContent=room.code;
    $('room-game-display').textContent=`ゲーム：${room.game==='ttt'?'まるばつゲーム':'オセロ'}${room.game==='ttt'?`（ステージ${room.stage+1}）`:''}`;
    $('players-list').innerHTML='';
    room.players.forEach((p,i)=>{
      const row=document.createElement('div');row.className='player-row';
      const name=document.createElement('strong');name.textContent=p.name+(p.host?'（部屋作成者）':'');
      const state=document.createElement('span');state.className='player-state';state.textContent=p.connected?'接続中':'再接続待ち';
      row.append(name,state);$('players-list').append(row);
    });
    $('room-message').textContent=room.message || (room.players.length<2?'友達の参加を待っています。':'2人揃いました。対戦を開始できます。');
    $('start-online').hidden=!myHost;
    $('start-online').disabled=room.players.length!==2||room.players.some(p=>!p.connected);
  }

  function renderMatch() {
    if(!room||!room.state)return;
    const s=room.state, hostMark=room.game==='ttt'?'X':'黒';
    const me=room.players.find(p=>p.host===myHost),opp=room.players.find(p=>p.host!==myHost);
    $('match-title').textContent=room.game==='ttt'?`まるばつゲーム：ステージ${room.stage+1}`:'オセロ';
    $('match-players').textContent=`${room.players[0]?.name||'---'}　対　${room.players[1]?.name||'---'}`;
    $('online-ttt-board').hidden=room.game!=='ttt';$('online-o-board').hidden=room.game!=='oth';$('online-counts').hidden=room.game!=='oth';
    $('rematch-online').hidden=!(s.over&&myHost);
    if(room.game==='ttt') renderTtt(s); else renderOthello(s);
  }
  function renderTtt(s) {
    const el=$('online-ttt-board');el.style.gridTemplateColumns=`repeat(${s.n},minmax(0,1fr))`;el.style.gridTemplateRows=`repeat(${s.n},minmax(0,1fr))`;el.style.setProperty('--gap',s.n>=6?'3px':'6px');el.innerHTML='';
    const mine=myHost?'X':'O';const disconnected=room.players.some(p=>!p.connected);
    s.board.forEach((v,i)=>{const b=document.createElement('button');b.className='cell'+(v?' '+v.toLowerCase():'')+(s.winningLine?.includes(i)?' winline':'');b.textContent=v||'';b.disabled=!!v||s.over||s.turn!==mine||disconnected;b.onclick=()=>socket.emit('tttMove',{index:i});el.append(b);});
    $('match-status').textContent=disconnected?'相手の再接続を待っています（最大60秒）。':s.over?(s.winner==='draw'?'引き分け！':s.winner===mine?'あなたの勝ち！':'あなたの負け…'):`${s.turn===mine?'あなた':'相手'}の番（${s.turn}）`;
  }
  const dirs=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
  function flips(board,i,p){if(board[i])return[];const r0=i>>3,c0=i&7,out=[];for(const[dr,dc]of dirs){let r=r0+dr,c=c0+dc,line=[];while(r>=0&&r<8&&c>=0&&c<8&&board[r*8+c]===-p){line.push(r*8+c);r+=dr;c+=dc;}if(line.length&&r>=0&&r<8&&c>=0&&c<8&&board[r*8+c]===p)out.push(...line);}return out;}
  function renderOthello(s) {
    const el=$('online-o-board');el.innerHTML='';const mine=myHost?1:-1;const disconnected=room.players.some(p=>!p.connected);const legal=new Set();if(!disconnected&&!s.over&&s.turn===mine)for(let i=0;i<64;i++)if(flips(s.board,i,mine).length)legal.add(i);
    for(let i=0;i<64;i++){const cell=document.createElement('button');cell.className='ocell'+(legal.has(i)?' legal':'')+(i===s.lastMove?' last':'');cell.disabled=!legal.has(i);if(s.board[i]){const d=document.createElement('span');d.className='disc '+(s.board[i]===1?'b':'w');cell.append(d);}cell.onclick=()=>socket.emit('othelloMove',{index:i});el.append(cell);}
    const black=s.board.filter(v=>v===1).length,white=s.board.filter(v=>v===-1).length;$('online-counts').innerHTML=`<span><i style="background:#111318"></i>黒 <strong>${black}</strong></span><span><i style="background:#f2f3f6"></i>白 <strong>${white}</strong></span>`;
    $('match-status').textContent=disconnected?'相手の再接続を待っています（最大60秒）。':s.over?(s.winner==='draw'?'引き分け！':s.winner===mine?'あなたの勝ち！':'あなたの負け…'):`${s.turn===mine?'あなた':'相手'}の番（${mine===1?'黒':'白'}）`;
    if(s.passed&&!s.over)$('match-status').textContent+=' ／ 相手がパスしました';
  }
  function leaveRoom() {
    if(!confirm('対戦ルームから退出しますか？退出すると相手の勝ちになります。'))return;
    socket.emit('leaveRoom');clearSession();room=null;showOnlinePanel('menu');setStatus('退出しました。');
  }
  // A browser refresh can restore the room using the private reconnect token.
  const raw=localStorage.getItem(sessionKey);if(raw){try{const s=JSON.parse(raw);if(s.code&&s.token){session=s;myToken=s.token;myHost=false;}}catch{clearSession();}}
  $('online-name').addEventListener('keydown',e=>{if(e.key==='Enter')saveName();});
})();
